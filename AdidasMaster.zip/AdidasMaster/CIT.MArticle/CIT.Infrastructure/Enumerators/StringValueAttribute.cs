﻿using System;

namespace CIT.MArticle.Infrastructure.Enumerators
{
    internal class StringValueAttribute : Attribute
    {
        private string _value;

        public StringValueAttribute(string value)
        {
            _value = value;
        }

        public string Value
        {
            get { return _value; }
        }
    }
}