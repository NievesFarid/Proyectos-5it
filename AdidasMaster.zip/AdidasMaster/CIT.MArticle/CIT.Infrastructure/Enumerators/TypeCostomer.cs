﻿namespace CIT.MArticle.Infrastructure.Enumerators
{
    public enum TypeCostomer
    {
        /// <summary>
        /// Liverpool
        /// </summary>
        LP = 1,

        /// <summary>
        /// Marti
        /// </summary>
        MT = 2
    }
}