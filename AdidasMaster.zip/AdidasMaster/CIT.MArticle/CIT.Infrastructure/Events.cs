﻿using CIT.MArticle.Data;
using CIT.MArticle.Data.Entities;
using System;

namespace CIT.MArticle.Infrastructure
{
    internal class Events
    {
        public static string UserId { get; set; }
        public static string Module { get; set; }
        public static string Reference { get; set; }
        public static string Event_description { get; set; }

        public static void Create()
        {
            try
            {
                using (var Context = new Master_Context(Global.ConnectionString))
                {
                    Context.EventLogs.Add(new EventLog()
                    {
                        User_id = UserId,
                        Module = Module,
                        Reference = Reference,
                        Event_description = Event_description,
                        Event_date = DateTime.Now
                    });

                    Context.SaveChanges();

                    UserId =null;
                    Module = null;
                    Reference = null;
                    Event_description = null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

    }
}
