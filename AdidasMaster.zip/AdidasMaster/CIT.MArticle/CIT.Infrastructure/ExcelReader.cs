﻿using ExcelDataReader;
using System.Data;
using System.IO;

namespace CIT.MArticle.Infrastructure
{
    public static class ExcelReader
    {

        private static Stream _stream;
        private static IExcelDataReader _reader = null;

        public static void Create(Stream stream, string FileName)
        {
            FileInfo fInfo = new FileInfo(FileName);
            _stream = stream;
            switch (fInfo.Extension)
            {
                case ".xls":
                    _reader = ExcelReaderFactory.CreateBinaryReader(stream);
                    break;
                case ".xlsx":
                    _reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
                    break;
            }
        }

        public static DataSet AsDataSet()
        {
            var conf = new ExcelDataSetConfiguration { ConfigureDataTable = _ => new ExcelDataTableConfiguration { UseHeaderRow = true } };
            var tables = _reader.AsDataSet(conf);
            _reader.Close();
            return tables;
        }

        public static DataTable AsDataSet(string Sheet)
        {
            var conf = new ExcelDataSetConfiguration { ConfigureDataTable = _ => new ExcelDataTableConfiguration { UseHeaderRow = true } };
            var table = _reader.AsDataSet(conf).Tables[Sheet];
            _reader.Close();
            return table;
        }

    }
}
