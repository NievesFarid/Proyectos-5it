﻿namespace CIT.MArticle.Infrastructure
{
    public class Global
    {

        /// <summary>
        /// Devuelve la cadena de conexión global del sistema
        /// </summary>
        public static string ConnectionString
        {
            get; set;
        }

    }
}