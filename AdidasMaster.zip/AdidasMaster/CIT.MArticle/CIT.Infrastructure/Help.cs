﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIT.MArticle.Infrastructure
{
    internal class Help
    {
        /// <summary>
        /// Devuelve el nombre del host local
        /// </summary>
        public static string HostNameLocal
        {
            get
            {
                return System.Net.Dns.GetHostName();
            }
        }

    }
}
