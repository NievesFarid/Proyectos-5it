﻿using CIT.MArticle.Data.Entities;
using CIT.MArticle.Infrastructure.Enumerators;
using System.Collections.Generic;
using System.Data;

namespace CIT.MArticle.Infrastructure.Interfaces
{
    public interface IProcess
    {
        /// <summary>
        /// Tipo de cliente
        /// </summary>
        TypeCostomer ProccessType { get; }

        string UserId { get; set; }

        /// <summary>
        /// Numero de cliente
        /// </summary>
        int NumberClient { get; }


        void Create();

        /// <summary>
        /// Devuelve la lista de archivos disponibles
        /// </summary>
        /// <returns></returns>
        IEnumerable<HistoryUploadsFile> GetFiles();


        /// <summary>
        /// Sube los datos al servidor SQL Server
        /// </summary>
        /// <param name="tDatas"></param>
        void UploadDatas(DataTable tDatas, string FileName);
    }
}

