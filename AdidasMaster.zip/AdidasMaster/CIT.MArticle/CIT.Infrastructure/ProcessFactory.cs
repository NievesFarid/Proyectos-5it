﻿using CIT.MArticle.Infrastructure.Enumerators;
using CIT.MArticle.Infrastructure.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace CIT.MArticle.Infrastructure
{
    public class ProcessFactory
    {
        private List<IProcess> _processes;
        private static ProcessFactory instance;

        private ProcessFactory()
        {
            _processes = new List<IProcess>();
            var assm = GetType().AssemblyQualifiedName.Split(',');
            _processes = Assembly.Load(assm[1]).GetTypes()
               .Where(itm => itm != null && itm.IsClass && itm.GetInterfaces().Any(ti => ti == typeof(IProcess)))
               .Select(type => (IProcess)Activator.CreateInstance(type)).ToList();
        }

        public static ProcessFactory Factory
        {
            get
            {
                if (instance == null)
                    instance = new ProcessFactory();
                return instance;
            }
        }

        public IProcess Create(string prefix)
        {
            var _type = (TypeCostomer)Enum.Parse(typeof(TypeCostomer), prefix);
            return _processes.FirstOrDefault(cmd => cmd.ProccessType == _type);
        }

    }
}