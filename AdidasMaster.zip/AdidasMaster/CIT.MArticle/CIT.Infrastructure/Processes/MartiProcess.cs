﻿using CIT.MArticle.Data;
using CIT.MArticle.Data.Entities;
using CIT.MArticle.Infrastructure.Enumerators;
using CIT.MArticle.Infrastructure.Interfaces;
using CIT.MArticle.Infrastructure.SQLClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;

namespace CIT.MArticle.Infrastructure.Processes
{
    public class MartiProcess : IProcess
    {
        /// <summary>
        /// Usuario
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Numero de cliente
        /// </summary>
        public int NumberClient => 4;

        /// <summary>
        /// Tipo de proceso
        /// </summary>
        public TypeCostomer ProccessType => TypeCostomer.MT;


        public void Create()
        {

        }


        public IEnumerable<HistoryUploadsFile> GetFiles()
        {
            try
            {
                // Devuelve la lista de documentos cargados para este cliente
                IEnumerable<HistoryUploadsFile> result;
                using (var Context = new Master_Context(Global.ConnectionString))
                {
                    result = (from items in Context.HistoryUploadsFiles
                              where items.CustomerId == NumberClient
                              select items).ToList();
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Sube los datos al servidor SQL Server
        /// </summary>
        /// <param name="tDatas"></param>
        public void UploadDatas(DataTable tDatas, string FileName)
        {
            try
            {
                // Se registra el archivo que se cargo
                using (var Context = new Master_Context(Global.ConnectionString))
                {
                    var upFile = new HistoryUploadsFile()
                    {
                        CustomerId = NumberClient,
                        UserId = UserId,
                        FileName = FileName,
                        LoadDate = DateTime.Now,
                        Status = "En Proceso",
                        WorkStation = Help.HostNameLocal
                    };

                    Context.Entry(upFile).State = EntityState.Added;
                    Context.SaveChanges();

                    // se realiza la carga mediante el metodo BulkCopy
                    tDatas.Columns.Add(new DataColumn() { ColumnName = "format", DataType = typeof(string), AllowDBNull = true });
                    tDatas.Columns.Add(new DataColumn() { ColumnName = "file_id", DataType = typeof(int), AllowDBNull = false, DefaultValue = upFile.Id });
                    foreach (DataRow orow in tDatas.Rows)
                    {
                        orow["format"] = (
                                           orow["CUSTOMER_PURCHASE_NO"].ToString().Contains("OUTLET") ? "OUT" :
                                           orow["CUSTOMER_PURCHASE_NO"].ToString().Contains("OUT") ? "OUT" :
                                           orow["CUSTOMER_PURCHASE_NO"].ToString().Contains("BOD") ? "OUT" :
                                           orow["CUSTOMER_PURCHASE_NO"].ToString().Contains("RMA") ? "RMA" :
                                           orow["CUSTOMER_PURCHASE_NO"].ToString().Contains("REALMA") ? "RMA" : "MTI"
                                           );
                    }

                    ClientSql sql = new ClientSql(Global.ConnectionString);
                    sql.BulkCopy(tDatas, "Pedidos_Sap");

                    // Se guarda el evento
                    Events.UserId = UserId;
                    Events.Module = "Cargas";
                    Events.Reference = FileName;
                    Events.Event_description = "Se carga el archivo al sistema";
                    Events.Create();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}