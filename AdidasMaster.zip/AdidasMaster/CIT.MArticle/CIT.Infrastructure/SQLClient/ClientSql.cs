﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace CIT.MArticle.Infrastructure.SQLClient
{
    public class ClientSql
    {
        private readonly SqlConnection Connection;

        public ClientSql(string connection)
        {
            Connection = new SqlConnection(connection);
        }

        public void BulkCopy(DataTable tdata, string DestinationTableName)
        {
            if (Connection.State == ConnectionState.Closed)
                Connection.Open();

            SqlTransaction transaction = Connection.BeginTransaction("BulkCopy_MArticles");

            try
            {
                SqlBulkCopy bulkCopy = new SqlBulkCopy(Connection, SqlBulkCopyOptions.Default, transaction);
                bulkCopy.BatchSize = 500;
                bulkCopy.DestinationTableName = DestinationTableName;

                foreach (DataColumn column in tdata.Columns)
                    bulkCopy.ColumnMappings.Add(column.ColumnName.ToLower(), column.ColumnName.ToLower());

                bulkCopy.WriteToServer(tdata);
                transaction.Commit();
            }
            catch (Exception ex)
            {
                if (transaction != null)
                    transaction.Rollback();

                throw ex;
            }
            finally
            {
                if (Connection.State == ConnectionState.Closed)
                    Connection.Open();
            }
        }

    }
}
