﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "AspNetRoles")]
    public class AspNetRoles
    {
        [Key, Column(name: "Id", Order = 0, TypeName = "nvarchar"), MaxLength(128)]
        public string Id { get; set; }

        [Required, Column(name: "Name", Order = 1, TypeName = "nvarchar")]
        public string Name { get; set; }

        [Required, Column(name: "Discriminator", Order = 2, TypeName = "nvarchar")]
        public string Discriminator { get; set; }
    }
}
