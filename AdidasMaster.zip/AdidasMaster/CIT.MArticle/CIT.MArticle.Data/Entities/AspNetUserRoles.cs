﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "AspNetUserRoles")]
    public class AspNetUserRoles
    {
        [Key, Column(name: "UserId", Order = 0, TypeName = "nvarchar"), MaxLength(128)]
        public string UserId { get; set; }

        [Key, Column(name: "RoleId", Order = 1, TypeName = "nvarchar"), MaxLength(128)]
        public string RoleId { get; set; }

    }
}
