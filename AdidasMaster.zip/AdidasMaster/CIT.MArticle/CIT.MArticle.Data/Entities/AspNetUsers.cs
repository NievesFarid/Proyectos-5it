﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "AspNetUsers")]
    public class AspNetUsers
    {
        [Key, Column(name: "Id", Order = 0, TypeName = "nvarchar")]
        public string Id { get; set; }

        [Column(name: "Name", Order = 1, TypeName = "varchar")]
        public string Name { get; set; }

        [Column(name: "LastName", Order = 2, TypeName = "varchar")]
        public string LastName { get; set; }

        [Required, Column(name: "IsEnabled", Order = 3, TypeName = "bit")]
        public bool IsEnabled { get; set; }

        [Column(name: "Email", Order = 4, TypeName = "nvarchar")]
        public string Email { get; set; }

        [Required, Column(name: "EmailConfirmed", Order = 5, TypeName = "bit")]
        public bool EmailConfirmed { get; set; }

        [Column(name: "PasswordHash", Order = 6, TypeName = "nvarchar")]
        public string PasswordHash { get; set; }

        [Column(name: "SecurityStamp", Order = 7, TypeName = "nvarchar")]
        public string SecurityStamp { get; set; }

        [Column(name: "PhoneNumber", Order = 8, TypeName = "nvarchar")]
        public string PhoneNumber { get; set; }

        [Required, Column(name: "PhoneNumberConfirmed", Order = 9, TypeName = "bit")]
        public bool PhoneNumberConfirmed { get; set; }

        [Required, Column(name: "TwoFactorEnabled", Order = 10, TypeName = "bit")]
        public bool TwoFactorEnabled { get; set; }

        [Column(name: "LockoutEndDateUtc", Order = 11, TypeName = "datetime")]
        public DateTime? LockoutEndDateUtc { get; set; }

        [Required, Column(name: "LockoutEnabled", Order = 12, TypeName = "bit")]
        public bool LockoutEnabled { get; set; }

        [Required, Column(name: "AccessFailedCount", Order = 13, TypeName = "int")]
        public int AccessFailedCount { get; set; }

        [Required, Column(name: "UserName", Order = 14, TypeName = "nvarchar")]
        public string UserName { get; set; }

        [Required, Column(name: "IsMaster", Order = 15, TypeName = "bit")]
        public bool IsMaster { get; set; }

        [Required, Column(name: "ParentClient", Order = 16, TypeName = "int")]
        public int ParentClient { get; set; }
    }
}
