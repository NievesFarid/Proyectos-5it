﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "Cat_Clasificacion")]
    public class Cat_Clasification
    {
        [Key, Column(name: "id_clasificacion", TypeName = "int")]
        public int id_clasificacion { get; set; }

        [Required, Column(name: "descripcion", TypeName = "varchar"), MaxLength(150)]
        public string Descripcion { get; set; }
    }
}
