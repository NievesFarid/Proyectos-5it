﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "Cat_Clasification_Type")]
    public class Cat_Clasification_Type
    {
        [Key, Column(name: "id_category", Order = 0, TypeName = "int")]
        public int id_category { get; set; }

        [Key, Column(name: "id_group", Order = 1, TypeName = "int")]
        public int id_group { get; set; }

        [Key, Column(name: "product_type", Order = 2, TypeName = "varchar"), MaxLength(50)]
        public string product_type { get; set; }

        [Key, Column(name: "id_clasification", Order = 3, TypeName = "int")]
        public int id_clasification { get; set; }

        [Column(name: "id_type", Order = 4, TypeName = "int")]
        public int id_type { get; set; }

        [Column(name: "active", Order = 5, TypeName = "bit")]
        public bool active { get; set; }
    }
}
