﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{

    [Table(name: "Cat_Equivalences_Categories")]
    public class Cat_Equivalences_Categories
    {
        [Key, Column(name: "category_id", Order = 0, TypeName = "int")]
        public int category_id { get; set; }

        [Key, Column(name: "customer_id", Order = 1, TypeName = "int")]
        public int customer_id { get; set; }

        [Column(name: "categoria_equivalent", Order = 2, TypeName = "varchar"), MaxLength(50)]
        public string categoria_equivalent { get; set; }

        [Column(name: "active", Order = 3, TypeName = "int")]
        public int active { get; set; }
    }
    
}
