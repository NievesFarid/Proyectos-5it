﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table (name: "Cat_Equivalences_Category_Mkt")]
    public class Cat_Equivalences_Category_Mkt
    {
        [Key,Column(name: "age_group", Order = 0, TypeName = "varchar"), MaxLength(50)]
        public string age_group { get; set; }

        [Key, Column(name: "product_type", Order = 1, TypeName = "varchar"), MaxLength(70)]
        public string product_type { get; set; }

        [Key, Column(name: "marketing_segment", Order = 2, TypeName = "varchar"), MaxLength(70)]
        public string marketing_segment { get; set; }

        [Column(name: "brand_id", Order = 3, TypeName = "int")]
        public int brand_id { get; set; }

        [Column(name: "customer_id", Order = 4, TypeName = "int")]
        public int customer_id { get; set; }

        [Column(name: "category_id", Order = 5, TypeName = "int")]
        public int category_id { get; set; }

        [Column(name: "active", Order = 6, TypeName = "bit")]
        public bool active { get; set; }
    }
}
