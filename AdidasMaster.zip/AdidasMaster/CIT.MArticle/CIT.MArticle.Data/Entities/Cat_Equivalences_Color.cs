﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table (name: "Cat_Equivalences_Color")]
    public class Cat_Equivalences_Color
    {
        [Column(name: "color_id", Order = 0, TypeName = "varchar"), MaxLength(255)]
        public string color_id { get; set; }

        [Column(name: "color_equivalent", Order = 1, TypeName = "varchar"), MaxLength(50)]
        public string color_equivalent { get; set; }

        [Column(name: "customer_id", Order = 2, TypeName = "int")]
        public int customer_id { get; set; }

        [Column(name: "active", Order = 3, TypeName = "int")]
        public int active { get; set; }
    }
}
