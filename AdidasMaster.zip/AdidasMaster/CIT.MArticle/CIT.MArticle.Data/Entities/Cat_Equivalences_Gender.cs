﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table (name: "Cat_Equivalences_Gender")]
    public class Cat_Equivalences_Gender
    {
        [Key, Column(name: "gender_id", Order = 0, TypeName = "int")]
        public int gender_id { get; set; }

        [Column(name: "gender", Order = 1, TypeName = "varchar"), MaxLength(50)]
        public string gender { get; set; }

        [Column(name: "age_group", Order = 2, TypeName = "varchar"), MaxLength(50)]
        public string age_group { get; set; }

        [Column(name: "gender_concat", Order = 3, TypeName = "varchar"), MaxLength(50)]
        public string gender_concat { get; set; }

        [Column(name: "genero_equivalent", Order = 4, TypeName = "varchar"), MaxLength(50)]
        public string genero_equivalent { get; set; }

        [Column(name: "customer_id", Order = 5, TypeName = "int")]
        public int customer_id { get; set; }

        [Column(name: "active", Order = 6, TypeName = "int")]
        public int active { get; set; }
    }
}
