﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "Cat_Equivalences_Material_Composition")]
    public class Cat_Equivalences_Material_Composition
    {
        [Key, Column(name: "id", Order = 0, TypeName = "varchar"), MaxLength(255)]
        public string id { get; set; }

        [Column(name: "material_composition_equivalent", Order = 1, TypeName = "varchar"), MaxLength(255)]
        public string material_composition_equivalent { get; set; }

        [Column(name: "customer_id", Order = 2, TypeName = "int")]
        public int customer_id { get; set; }

        [Column(name: "active", Order = 3, TypeName = "int")]
        public int active { get; set; }
    }
}
