﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table (name: "Cat_Equivalences_Products")]
    public class Cat_Equivalences_Products
    {
        [Key, Column(name: "product_type", Order = 0, TypeName = "varchar"), MaxLength(255)]
        public string product_type { get; set; }

        [Column(name: "product_type_equivalent", Order = 1, TypeName = "varchar"), MaxLength(255)]
        public string product_type_equivalent { get; set; }

        [Column(name: "customer_id", Order = 2, TypeName = "int")]
        public int customer_id { get; set; }

        [Column(name: "active", Order = 3, TypeName = "bit")]
        public bool active { get; set; }
    }
}
