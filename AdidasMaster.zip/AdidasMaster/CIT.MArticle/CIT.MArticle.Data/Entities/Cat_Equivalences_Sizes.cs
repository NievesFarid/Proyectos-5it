﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace CIT.MArticle.Data.Entities
{
    [Table (name: "Cat_Equivalences_Sizes")]
    public class Cat_Equivalences_Sizes
    {
        [Key, Column(name: "id_size", Order = 0, TypeName = "int")]
        public int id_size { get; set; }

        [Column(name: "customer_id", Order = 1, TypeName = "int")]
        public int customer_id { get; set; }

        [Key,Column(name: "category_id", Order = 2, TypeName = "int")]
        public int category_id { get; set; }

        [Key,Column(name: "article_no", Order = 3, TypeName = "nchar"),MaxLength(10)]
        public string article_no { get; set; }

        [Key,Column(name: "product_type", Order = 4, TypeName = "varchar"), MaxLength(50)]
        public string product_type { get; set; }

        [Key,Column(name: "size_addidas", Order = 5, TypeName = "varchar"), MaxLength(50)]
        public string size_addidas { get; set; }

        [Column(name: "equivalent_size", Order = 6, TypeName = "varchar"), MaxLength(50)]
        public string equivalent_size { get; set; }

        [Column(name: "size", Order = 7, TypeName = "varchar"), MaxLength(50)]
        public string size { get; set; }

        [Column(name: "ean", Order = 8, TypeName = "varchar"), MaxLength(75)]
        public string ean { get; set; }

        [Column(name: "active", Order = 9, TypeName = "bit")]
        public bool active { get; set; }
    }
}
