﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table (name: "Cat_Equivalences_Type")]
    public class Cat_Equivalences_Type
    {
        [Key, Column(name: "type_id", Order = 0, TypeName = "int")]
        public int type_id { get; set; }

        [Column(name: "customer_id", Order = 1, TypeName = "int")]
        public int customer_id { get; set; }

        [Column(name: "type", Order = 2, TypeName = "varchar"), MaxLength(30)]
        public string type { get; set; }

        [Column(name: "active", Order = 3, TypeName = "int")]
        public int active { get; set; }
    }
}
