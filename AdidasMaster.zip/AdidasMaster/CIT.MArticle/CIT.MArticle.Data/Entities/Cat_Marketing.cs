﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "Cat_Marketing")]
    public class Cat_Marketing
    {
        [Key, Column(name: "article_no", Order = 0, TypeName = "varchar"), MaxLength(50)]
        public string article_no { get; set; }

        [Column(name: "brand_id", Order = 1, TypeName = "varchar"), MaxLength(50)]
        public string brand_id { get; set; }

        [Column(name: "model_name", Order = 2, TypeName = "varchar"), MaxLength(150)]
        public string model_name { get; set; }

        [Column(name: "marketing_segment", Order = 3, TypeName = "varchar"), MaxLength(100)]
        public string marketing_segment { get; set; }

        [Column(name: "colour", Order = 4, TypeName = "varchar"), MaxLength(255)]
        public string colour { get; set; }

        [Column(name: "product_type", Order = 5, TypeName = "varchar"), MaxLength(255)]
        public string product_type { get; set; }

        [Column(name: "gender", Order = 6, TypeName = "varchar"), MaxLength(50)]
        public string gender { get; set; }

        [Column(name: "age_group", Order = 7, TypeName = "varchar"), MaxLength(50)]
        public string age_group { get; set; }

        [Column(name: "technology", Order = 8, TypeName = "varchar"), MaxLength(255)]
        public string technology { get; set; }

        [Column(name: "material_composition", Order = 9, TypeName = "varchar"), MaxLength(255)]
        public string material_composition { get; set; }

        [Column(name: "category_id", Order = 10, TypeName = "varchar"), MaxLength(10)]
        public string category_id { get; set; }

        [Column(name: "image_name", Order = 11, TypeName = "varchar"), MaxLength(255)]
        public string image_name { get; set; }

        [Column(name: "customer_id", Order = 12, TypeName = "int")]
        public int customer_id { get; set; }

        [Column(name: "active", Order = 13, TypeName = "bit")]
        public bool active { get; set; }
    }
}
}
