﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table (name: "Cat_Product_Clasification")]
    public class Cat_Product_Clasification
    {
        [Key, Column(name: "category_id", Order = 0, TypeName = "int")]
        public int category_id { get; set; }

        [Column(name: "product_type", Order = 1, TypeName = "varchar"), MaxLength(75)]
        public string product_type { get; set; }

        [Column(name: "customer_id", Order = 2, TypeName = "int")]
        public int customer_id { get; set; }

        [Column(name: "clasification_id", Order = 3, TypeName = "int")]
        public int clasification_id { get; set; }

        [Column(name: "grup_id", Order = 4, TypeName = "int")]
        public int grup_id { get; set; }

        [Column(name: "active", Order = 5, TypeName = "int")]
        public int active { get; set; }
    }
}
