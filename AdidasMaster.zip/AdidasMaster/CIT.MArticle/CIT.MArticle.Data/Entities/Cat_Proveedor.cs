﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "Cat_Proveedor")]
    public class Cat_Proveedor
    {
        [Key, Column(name: "proveedor_id", Order = 0, TypeName = "int")]
        public int Proveedor_Id { get; set; }

        [Required, Column(name: "customer_id", Order = 1, TypeName = "int")]
        public int Customer_Id { get; set; }

        [Column(name: "proveedor", Order = 2, TypeName = "varchar"), MaxLength(50)]
        public string proveedor { get; set; }

        [Column(name: "descripcion", Order = 3, TypeName = "varchar"), MaxLength(250)]
        public string Descripcion { get; set; }

        [Required, Column(name: "activo", Order = 4, TypeName = "bit")]
        public bool activo { get; set; }


    }
}
