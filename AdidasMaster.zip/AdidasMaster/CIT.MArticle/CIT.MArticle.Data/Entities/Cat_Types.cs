﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table (name: "Cat_Types")]
    public class Cat_Types
    {
        [Key, Column(name: "id_type", Order = 0, TypeName = "int")]
        public int id_type { get; set; }

        [Column(name: "customer_id", Order = 1, TypeName = "int")]
        public int customer_id { get; set; }

        [Column(name: "description_type", Order = 2, TypeName = "varchar"), MaxLength(130)]
        public int description_type { get; set; }

        [Column(name: "active", Order = 3, TypeName = "bit")]
        public bool active { get; set; }
    }
}
