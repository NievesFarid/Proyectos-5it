﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace CIT.MArticle.Data.Entities
{
    [Table (name: "Cato_Rules_Types")]
    public class Cato_Rules_Types
    {
        [Key, Column(name: "category_id", Order = 0, TypeName = "int")]
        public int category_id { get; set; }

        [Key,Column(name: "grup_id", Order = 1, TypeName = "int")]
        public int grup_id { get; set; }

        [Key,Column(name: "product_type", Order = 2, TypeName = "varchar"), MaxLength(50)]
        public string product_type { get; set; }

        [Key,Column(name: "clasification_id", Order = 3, TypeName = "int")]
        public int clasification_id { get; set; }

        [Column(name: "type_id", Order = 4, TypeName = "int")]
        public int type_id { get; set; }

        [Column(name: "active", Order = 5, TypeName = "bit")]
        public bool active { get; set; }
    }
}
