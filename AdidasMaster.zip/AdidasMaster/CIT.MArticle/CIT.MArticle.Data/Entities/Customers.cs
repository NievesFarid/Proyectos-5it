﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "Customers")]
    public class Customers
    {
        [Key, Column(name: "id", Order = 0, TypeName = "int")]
        public int Id { get; set; }

        [Required, Column(name: "customer_name", Order = 1, TypeName = "varchar"), MaxLength(150)]
        public string Customer_name { get; set; }

        [Column(name: "prefix", Order = 2, TypeName = "varchar"), MaxLength(25)]
        public string Prefix { get; set; }

        [Column(name: "directory_upload", Order = 3, TypeName = "varchar"), MaxLength(250)]
        public string Directory_upload { get; set; }

        [Required, Column(name: "creation_date", Order = 4, TypeName = "datetime")]
        public DateTime Creation_date { get; set; }

    }
}
