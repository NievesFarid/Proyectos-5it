﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table( name: "EventLog")]
    public class EventLog
    {
        /// <summary>
        /// Identificador único del evento
        /// </summary>
        [Key, Column(name: "event_id", Order = 0, TypeName = "int")]
        public int Event_id { get; set; }

        /// <summary>
        /// Identificador del usuario que origino el evento
        /// </summary>
        [Required, Column(name: "user_id", Order = 1, TypeName = "varchar"), Index(name: "IX_EventLog_N1", order: 1)]
        public string User_id { get; set; }

        /// <summary>
        /// Modulo donde se origino el evento
        /// </summary>
        [Column(name: "module", Order = 2, TypeName = "varchar")]
        public string Module { get; set; }

        /// <summary>
        /// Referencia de seguimiento para el evento
        /// </summary>
        [Column(name: "reference", Order = 3, TypeName = "varchar"), MaxLength(100, ErrorMessage = "La referencia no puede exceder de 100 caracteres")]
        public string Reference { get; set; }

        /// <summary>
        /// Descripción del evento
        /// </summary>
        [Required, Column(name: "event_description", Order = 4, TypeName = "text")]
        public string Event_description { get; set; }

        /// <summary>
        /// Fecha y hora en la que se genero el evento
        /// </summary>
        [Required, Column(name: "event_date", Order = 5, TypeName = "datetime")]
        public DateTime Event_date { get; set; }
    }
}
