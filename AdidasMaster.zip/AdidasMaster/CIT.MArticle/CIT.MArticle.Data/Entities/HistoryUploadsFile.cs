﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "HistoryUploadsFile")]
    public class HistoryUploadsFile
    {
        [Key, Column(name: "Id", Order = 0, TypeName = "int")]
        public int Id { get; set; }

        [Required, Column(name: "customer_id", Order = 1, TypeName = "int")]
        public int CustomerId { get; set; }

        [Required, Column(name: "user_id", Order = 2, TypeName = "varchar")]
        public string UserId { get; set; }

        [Required, Column(name: "file_name", Order = 3, TypeName = "varchar"), MaxLength(150)]
        public string FileName { get; set; }

        [Required, Column(name: "load_date", Order = 4, TypeName = "datetime")]
        public DateTime LoadDate { get; set; }

        [Column(name: "status", Order = 5, TypeName = "varchar"), MaxLength(100)]
        public string Status { get; set; }

        [Column(name: "workstation", Order = 6, TypeName = "varchar"), MaxLength(50)]
        public string WorkStation { get; set; }

    }
}
