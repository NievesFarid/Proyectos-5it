﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "Options")]
    public class Option
    {
        [Key, Column(name: "option_id", Order = 0, TypeName = "int")]
        public int option_id { get; set; }

        [Required, Column(name: "option_key", Order = 1, TypeName = "varchar"), MaxLength(450)]
        public string option_key { get; set; }

        [Column(name: "option_value", Order = 2, TypeName = "varchar")]
        public string option_value { get; set; }

        [Column(name: "auto", Order = 3, TypeName = "bit")]
        public bool auto { get; set; }
    }
}
