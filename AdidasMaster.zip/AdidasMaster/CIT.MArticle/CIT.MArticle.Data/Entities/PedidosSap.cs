﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "Pedidos_Sap")]
    public class PedidosSap
    {
        [Key, Column(name: "id", Order = 0, TypeName = "int")]
        public int Id { get; set; }

        [Required, Column(name: "customer_id", Order = 1, TypeName = "int")]
        public int Customer_Id { get; set; }

        [Column(name: "file_id", Order = 2, TypeName = "int")]
        public int File_Id { get; set; }

        [Column(name: "sales_organization", Order = 3, TypeName = "varchar"), MaxLength(50)]
        public string Sales_Organization { get; set; }

        [Column(name: "release_strategy", Order = 4, TypeName = "varchar"), MaxLength(150)]
        public string Release_Strategy { get; set; }

        [Column(name: "customer_no", Order = 5, TypeName = "varchar"), MaxLength(50)]
        public string Customer_No { get; set; }

        [Column(name: "sold_to_name", Order = 6, TypeName = "varchar"), MaxLength(150)]
        public string Sold_To_Name { get; set; }

        [Column(name: "ship_to", Order = 7, TypeName = "varchar"), MaxLength(50)]
        public string Ship_To { get; set; }

        [Column(name: "ship_to_name", Order = 8, TypeName = "varchar"), MaxLength(150)]
        public string Ship_To_Name { get; set; }

        [Column(name: "sales_type", Order = 9, TypeName = "varchar"), MaxLength(150)]
        public string Sales_Type { get; set; }

        [Column(name: "customer_purchase_no", Order = 10, TypeName = "varchar"), MaxLength(50)]
        public string Customer_Purchase_No { get; set; }

        [Column(name: "so_creation_date", Order = 11, TypeName = "date")]
        public DateTime So_Creation_Date { get; set; }

        [Column(name: "sales_order_delivery_block", Order = 12, TypeName = "varchar"), MaxLength(150)]
        public string Sales_Order_Delivery_Block { get; set; }

        [Column(name: "order_number", Order = 13, TypeName = "varchar"), MaxLength(25)]
        public string Order_Number { get; set; }

        [Column(name: "rdd", Order = 14, TypeName = "date")]
        public DateTime RDD { get; set; }

        [Column(name: "mes", Order = 15, TypeName = "varchar"), MaxLength(100)]
        public string Mes { get; set; }

        [Column(name: "valid_to", Order = 16, TypeName = "date")]
        public DateTime Valid_To { get; set; }

        [Column(name: "requested_date", Order = 17, TypeName = "date")]
        public DateTime Requested_Date { get; set; }

        [Column(name: "sch_line_date", Order = 18, TypeName = "date")]
        public DateTime Sch_Line_Date { get; set; }

        [Column(name: "article_no", Order = 19, TypeName = "varchar"), MaxLength(50)]
        public string Article_No { get; set; }

        [Column(name: "article_name", Order = 20, TypeName = "varchar"), MaxLength(150)]
        public string Article_Name { get; set; }

        [Column(name: "colour", Order = 21, TypeName = "varchar"), MaxLength(100)]
        public string Colour { get; set; }

        [Column(name: "material_division", Order = 22, TypeName = "varchar"), MaxLength(150)]
        public string Material_Division { get; set; }

        [Column(name: "retail_intro_date", Order = 23, TypeName = "date")]
        public DateTime Retail_Intro_Date { get; set; }

        [Column(name: "ean_upc", Order = 24, TypeName = "varchar"), MaxLength(50)]
        public string Ean_Upc { get; set; }

        [Column(name: "size", Order = 25, TypeName = "varchar"), MaxLength(50)]
        public string Size { get; set; }

        [Column(name: "article_no2", Order = 26, TypeName = "varchar"), MaxLength(70)]
        public string Article_No2 { get; set; }

        [Column(name: "techsize", Order = 27, TypeName = "varchar"), MaxLength(50)]
        public string Techsize { get; set; }

        [Column(name: "quantity_ordered", Order = 28, TypeName = "varchar"), MaxLength(150)]
        public string Quantity_Ordered { get; set; }

        [Column(name: "call_off_quantity", Order = 29, TypeName = "varchar"), MaxLength(150)]
        public string Call_Off_Quantity { get; set; }

        [Column(name: "cancelled_qty", Order = 30, TypeName = "varchar"), MaxLength(150)]
        public string Cancelled_Qty { get; set; }

        [Column(name: "outstanding_qty", Order = 31, TypeName = "varchar"), MaxLength(150)]
        public string Outstanding_Qty { get; set; }

        [Column(name: "allocated_qty_po", Order = 32, TypeName = "varchar"), MaxLength(150)]
        public string Allocated_Qty_Po { get; set; }

        [Column(name: "allocated_qty_batch", Order = 33, TypeName = "varchar"), MaxLength(150)]
        public string Allocated_Qty_Batch { get; set; }

        [Column(name: "delivered_qty", Order = 34, TypeName = "varchar"), MaxLength(50)]
        public string Delivered_Qty { get; set; }

        [Column(name: "post_good_issue_qty", Order = 35, TypeName = "varchar"), MaxLength(50)]
        public string Post_Good_Issue_Qty { get; set; }

        [Column(name: "invoiced_qty", Order = 36, TypeName = "varchar"), MaxLength(50)]
        public string Invoiced_Qty { get; set; }

        [Column(name: "discount", Order = 37, TypeName = "decimal")]
        public decimal Discount { get; set; }

        [Column(name: "season_indicator", Order = 38, TypeName = "varchar"), MaxLength(50)]
        public string Season_Indicator { get; set; }

        [Column(name: "allocated_value", Order = 39, TypeName = "decimal")]
        public decimal Allocated_Value { get; set; }

        [Column(name: "sea", Order = 40, TypeName = "varchar"), MaxLength(70)]
        public string Sea { get; set; }

        [Column(name: "net_price_unit", Order = 41, TypeName = "decimal")]
        public decimal Net_Price_Unit { get; set; }

        [Column(name: "recommended_retail_price", Order = 42, TypeName = "decimal")]
        public decimal Recommender_Retail_price { get; set; }

        [Column(name: "act_gds_mvmnt_date", Order = 43, TypeName = "varchar"), MaxLength(50)]
        public string Act_Gds_Mvmnt_Date { get; set; }

        [Column(name: "order_reason_description", Order = 44, TypeName = "varchar"), MaxLength(150)]
        public string Order_Reason_Description { get; set; }

        [Column(name: "regular_clearance", Order = 45, TypeName = "varchar"), MaxLength(150)]
        public string Regular_Clearance { get; set; }

        [Column(name: "order_reason", Order = 46, TypeName = "varchar"), MaxLength(150)]
        public string Order_Reason { get; set; }

        [Column(name: "rj", Order = 47, TypeName = "varchar"), MaxLength(150)]
        public string RJ { get; set; }

        [Column(name: "description", Order = 48, TypeName = "varchar"), MaxLength(250)]
        public string Description { get; set; }

        [Column(name: "rej_dt", Order = 49, TypeName = "varchar"), MaxLength(250)]
        public string Rej_Dt { get; set; }

        [Column(name: "created_by", Order = 50, TypeName = "varchar"), MaxLength(250)]
        public string Created_By { get; set; }

        [Column(name: "format", Order = 51, TypeName = "varchar"), MaxLength(10)]
        public string Format { get; set; }

        [Column(name: "costo", Order = 52, TypeName = "decimal")]
        public decimal Costo { get; set; }

        [Column(name: "precioportal", Order = 53, TypeName = "varchar"), MaxLength(70)]
        public string Precioportal { get; set; }

        [Column(name: "estatus", Order = 54, TypeName = "varchar"), MaxLength(70)]
        public string Estatus { get; set; }

        [Column(name: "accion", Order = 55, TypeName = "varchar"), MaxLength(70)]
        public string Accion { get; set; }

        [Column(name: "seccion", Order = 56, TypeName = "varchar"), MaxLength(70)]
        public string Seccion { get; set; }

        [Column(name: "seccion2", Order = 57, TypeName = "varchar"), MaxLength(70)]
        public string Seccion2 { get; set; }

        [Column(name: "seccionecomm", Order = 58, TypeName = "varchar"), MaxLength(70)]
        public string Seccionecomm { get; set; }

        [Column(name: "concepto", Order = 59, TypeName = "varchar"), MaxLength(70)]
        public string Concepto { get; set; }

        [Column(name: "producttype", Order = 60, TypeName = "varchar"), MaxLength(70)]
        public string Producttype { get; set; }

        [Column(name: "manga", Order = 61, TypeName = "varchar"), MaxLength(70)]
        public string Manga { get; set; }
    
        [Column(name: "genero", Order = 62, TypeName = "varchar"), MaxLength(70)]
        public string Genero { get; set; }

        [Column(name: "agegroup", Order = 63, TypeName = "varchar"), MaxLength(70)]
        public string Agegroup { get; set; }

        [Column(name: "sportsdescription", Order = 64, TypeName = "varchar"), MaxLength(70)]
        public string Sportsdescription { get; set; }

        [Column(name: "marca", Order = 65, TypeName = "varchar"), MaxLength(70)]
        public string Marca { get; set; }

        [Column(name: "submarca", Order = 66, TypeName = "varchar"), MaxLength(70)]
        public string Submarca { get; set; }

        [Column(name: "producto_liverpool", Order = 67, TypeName = "varchar"), MaxLength(70)]
        public string Producto_Liverpool { get; set; }

        [Column(name: "suela", Order = 68, TypeName = "varchar"), MaxLength(70)]
        public string Suela { get; set; }
    }
}
