﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CIT.MArticle.Data.Entities
{
    [Table(name: "vw_articles_sap")]
    public class Vw_articles_sap
    {
        [Key, Column(name: "RowNumber", TypeName = "int")]
        public int RowNumber { get; set; }

        [Column(name: "file_id", TypeName = "int")]
        public int File_id { get; set; }
        [Column(name: "customer_id", TypeName = "int")]
        public int Customer_id { get; set; }

        [Column(name: "article_no", TypeName = "varchar")]
        public string Article_no { get; set; }

        [Column(name: "color", TypeName = "varchar")]
        public string Color { get; set; }

        [Column(name: "product", TypeName = "varchar")]
        public string Product { get; set; }

        [Column(name: "product_type", TypeName = "varchar")]
        public string Product_type { get; set; }

        [Column(name: "marketing_segment", TypeName = "varchar")]
        public string Marketing_segment { get; set; }

        [Column(name: "age_group", TypeName = "varchar")]
        public string Age_group { get; set; }

        [Column(name: "article_description", TypeName = "varchar")]
        public string Article_description { get; set; }

        [Column(name: "gender", TypeName = "varchar")]
        public string Gender { get; set; }

        [Column(name: "material", TypeName = "varchar")]
        public string Material { get; set; }

        [Column(name: "tecnology", TypeName = "varchar")]
        public string Tecnology { get; set; }

        [Column(name: "equivalent_size", TypeName = "varchar")]
        public string Equivalent_size { get; set; }

        [Column(name: "size", TypeName = "varchar")]
        public string Size { get; set; }

        [Column(name: "marca", TypeName = "varchar")]
        public string Marca { get; set; }

        [Column(name: "category_id", TypeName = "int")]
        public int Category_id { get; set; }

        [Column(name: "category", TypeName = "varchar")]
        public string Category { get; set; }

        [Column(name: "clasification_id", TypeName = "int")]
        public int Clasification_id { get; set; }

        [Column(name: "clasification", TypeName = "varchar")]
        public string Clasification { get; set; }

        [Column(name: "group_id", TypeName = "int")]
        public int Group_id { get; set; }

        [Column(name: "type_id", TypeName = "int")]
        public int Type_id { get; set; }

        [Column(name: "type", TypeName = "varchar")]
        public string Type { get; set; }
    }
}
