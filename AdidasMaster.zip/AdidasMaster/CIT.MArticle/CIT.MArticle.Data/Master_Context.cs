﻿using System.Data.Entity;
using CIT.MArticle.Data.Entities;

namespace CIT.MArticle.Data
{
    public class Master_Context : DbContext
    {

        public Master_Context(string connection) : base(connection)
        {
            Configuration.ProxyCreationEnabled = false;
        }

        public DbSet<AspNetRoles> AspNetRoles { get; set; }   
        public DbSet<Customers> Customers { get; set; }
        public DbSet<AspNetUserRoles> AspNetUserRoles { get; set; }
        public DbSet<AspNetUsers> AspNetUsers { get; set; }
        public DbSet<Cat_Proveedor> Cat_Proveedores { get; set; }
        public DbSet<EventLog> EventLogs { get; set; }
        public DbSet<HistoryUploadsFile> HistoryUploadsFiles { get; set; }
        public DbSet<Option> Options { get; set; }
        public DbSet<PedidosSap> PedidosSap { get; set; }

        public DbSet<Vw_articles_sap> Vw_articles_sap { get; set; }
    }
}
