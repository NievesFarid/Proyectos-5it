﻿namespace CIT.MArticle.Web
{
    public enum Mensager
    {
        Info = 1,
        Warning = 2,
        Success = 3,
        Danger = 4
    }
}