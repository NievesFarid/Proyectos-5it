﻿using CIT.MArticle.Data;
using System;
using System.Configuration;
using System.Linq;

namespace CIT.MArticle.Web
{
    public class GlobalConfiguration
    {

        static Master_Context Context = new Master_Context(ConnectionString);

        /// <summary>
        /// Tiempo de espera antes de remover las cajas de alertas de la interfaz de usuario
        /// </summary>
        public static int BoxNotificationTimeout { get => 6000; }


        /// <summary>
        /// Devuelve la cadena de conexión global del sistema
        /// </summary>
        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["CIT.MArticle.Web.Properties.Settings.ADMaster_Conenction"].ConnectionString;
            }
        }

        /// <summary>
        /// Tamaño maximo de carga durante el POST
        /// </summary>
        public static int MaxSizePost
        {
            get
            {
                var value = Context.Options.Single(o => o.option_key == "UploadMax").option_value;
                return Convert.ToInt32(value);
            }
        }

        /// <summary>
        /// Directorio de carga de archivos
        /// </summary>
        public static string DirectoryUpload
        {
            get
            {
                return Context.Options.Single(o => o.option_key == "DirectoryUpload").option_value;
            }
        }

    }
}