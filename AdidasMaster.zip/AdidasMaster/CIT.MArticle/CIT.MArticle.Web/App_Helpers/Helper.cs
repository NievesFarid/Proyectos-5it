﻿using CIT.MArticle.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace CIT.MArticle.Web
{
    public static class Helper
    {

        /// <summary>
        /// Genera una lista de valores para un DropDownList de los roles en el sistema
        /// </summary>
        /// <param name="ItemSelected"></param>
        /// <returns></returns>
        public static IEnumerable<SelectListItem> DropDownRoles(string ItemSelected = "")
        {
            IEnumerable<SelectListItem> DropDownList;
            using (var Context = new Master_Context(GlobalConfiguration.ConnectionString))
            {
                IEnumerable<SelectListItem> root = new List<SelectListItem>() { new SelectListItem() { Text = "-- Seleccione --", Value = "-1", Disabled = true, Selected = (ItemSelected == "") } };

                // Lista de organizaciones
                var result = (from xelem in Context.AspNetRoles
                              select new SelectListItem
                              {
                                  Value = xelem.Id,
                                  Text = xelem.Name,
                                  Disabled = false,
                                  Selected = (xelem.Id == ItemSelected)
                              }).ToList();

                DropDownList = root.Union(result);
            }

            return DropDownList;
        }


        /// <summary>
        /// Genera una lista de valores para un DropDownList de los clientes registrados
        /// </summary>
        /// <param name="ItemSelected">Si se proporciona un Id valido el elemento de lista quedara activado en automatico</param>
        /// <returns></returns>
        public static IEnumerable<SelectListItem> DropDownCustomer(int ItemSelected = -1)
        {
            var DropDown = new List<SelectListItem>() { new SelectListItem() { Text = "-- Sin registros --", Value = "-1", Disabled = true, Selected = false } };
            using (var Context = new Master_Context(GlobalConfiguration.ConnectionString))
            {
                DropDown = (from client in Context.Customers
                            where client.Prefix != "SYS"
                            select new SelectListItem
                            {
                                Value = client.Id.ToString(),
                                Text = client.Customer_name,
                                Selected = (client.Id == ItemSelected)
                            }).ToList();

                //if ((ItemSelected != -1 || ItemSelected != 0) && DropDown.Count > 0)
                //    DropDown.AsEnumerable().SingleOrDefault(item => item.Value == ItemSelected.ToString()).Selected = true;
            }

            return DropDown;
        }


        /// <summary>
        /// Devuelve los mensajes de una exepción generada durante la ejecución del programa
        /// </summary>
        /// <param name="exception">Representa una excepción del programa</param>
        /// <returns>string</returns>
        public static string GetInnerException(Exception exception)
        {
            var message = new StringBuilder();
            try
            {
                while (exception != null)
                {
                    if (message.Length == 0)
                        message.Append(exception.Message);
                    else
                        message.Append(string.Format("\n {0}", exception.Message));

                    exception = exception.InnerException;
                }
            }
            catch (Exception)
            {
                message.Append("Error durante la captura de la excepción");
            }

            return message.ToString();
        }

    }
}