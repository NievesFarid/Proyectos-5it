﻿using Microsoft.Ajax.Utilities;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace CIT.MArticle.Web
{
    public static class HtmlHelperExtensions
    {

        /// <summary>
        ///     Returns an unordered list (ul element) of validation messages that utilizes bootstrap markup and styling.
        /// </summary>
        /// <param name="htmlHelper"></param>
        /// <param name="alertType">The alert type styling rule to apply to the summary element.</param>
        /// <param name="heading">The optional value for the heading of the summary element.</param>
        /// <returns></returns>
        public static HtmlString ValidationBootstrap(this HtmlHelper htmlHelper, string heading = "", string alertType = "danger")
        {
            if (htmlHelper.ViewData.ModelState.IsValid)
                return new HtmlString(string.Empty);

            var sb = new StringBuilder();
            sb.AppendFormat("<div class=\"alert alert-{0} alert-dismissible fade show\" role=\"alert\">", alertType);

            if (!heading.IsNullOrWhiteSpace())
                sb.AppendFormat("<h5 class=\"alert-heading\">{0}</h5>", heading);

            sb.Append("<p class=\"mb-0\">");
            sb.Append(htmlHelper.ValidationSummary());
            sb.Append("</p>");
            sb.Append("<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>");
            sb.Append("</div>");

            return new HtmlString(sb.ToString());
        }

    }
}