﻿using System.Web.Optimization;

namespace CIT.MArticle.Web
{
    public class BundleConfig
    {
        // Para obtener más información sobre las uniones, visite https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {

            bundles.Add(new ScriptBundle("~/monster/scripts")
                .Include(
                        "~/Scripts/plugins/jquery/jquery.min.js",
                        // Bootstrap tether Core JavaScript
                        "~/Scripts/plugins/bootstrap/js/popper.min.js",
                        "~/Scripts/plugins/bootstrap/js/bootstrap.min.js",
                        // slimscrollbar scrollbar JavaScript
                        "~/Scripts/js/jquery.slimscroll.js",
                        // Wave Effects
                        "~/Scripts/js/waves.js",
                        // Menu sidebar 
                        "~/Scripts/js/sidebarmenu.js",
                        // stickey kit
                        "~/Scripts/plugins/sticky-kit-master/dist/sticky-kit.min.js",
                        // Custom JavaScript
                        "~/Scripts/js/custom.min.js",
                        // Style switcher
                        "~/Scripts/plugins/styleswitcher/jQuery.style.switcher.js",
                        "~/Scripts/plugins/toast-master/js/jquery.toast.js"
                        ));

            bundles.Add(new ScriptBundle("~/scripts/custom").Include(
               "~/Scripts/jscustom.js"
               ));


            bundles.Add(new ScriptBundle("~/monster/datatable").Include(
                   "~/Scripts/plugins/datatables/datatables.min.js"
                ));

            bundles.Add(new ScriptBundle("~/monster/Dropzone").Include(
                  "~/Scripts/Dropzone520/dropzone.js"
               ));




            // Estilos
            // -------------------------------

            bundles.Add(new StyleBundle("~/Content/css")
                .Include(
                      // Bootstrap Core CSS
                      "~/Scripts/plugins/bootstrap/css/bootstrap.min.css",
                      "~/Scripts/plugins/toast-master/css/jquery.toast.css"
                      ));

            bundles.Add(new StyleBundle("~/Content/Dropzone")
               .Include(
                     // Dropzone css
                     "~/Scripts/plugins/plugins/dropzone-master/dist/dropzone.css"
                     ));




            BundleTable.EnableOptimizations = false;

            //bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
            //            "~/Scripts/jquery-{version}.js"));

            //bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
            //            "~/Scripts/jquery.validate*"));

            //// Utilice la versión de desarrollo de Modernizr para desarrollar y obtener información. De este modo, estará
            //// para la producción, use la herramienta de compilación disponible en https://modernizr.com para seleccionar solo las pruebas que necesite.
            //bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
            //            "~/Scripts/modernizr-*"));

            //bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
            //          "~/Scripts/bootstrap.js"));

            //bundles.Add(new StyleBundle("~/Content/css").Include(
            //          "~/Content/bootstrap.css",
            //          "~/Content/site.css"));

        }
    }
}
