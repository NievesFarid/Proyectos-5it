﻿using CIT.MArticle.Data;
using CIT.MArticle.Data.Entities;
using CIT.MArticle.Infrastructure;
using CIT.MArticle.Web.Models;
using Microsoft.AspNet.Identity;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CIT.MArticle.Web.Controllers
{
    [Authorize]
    public class CustomersController : Controller
    {

        // GET: Customers
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

        [Authorize]
        [HttpGet]
        public ActionResult Uploads()
        {
            try
            {
                ViewBag.Title = "Carga de pedido";
                ViewBag.jsRoles = new string[] { "Dropzone" };
                ViewBag.MaxSizePost = GlobalConfiguration.MaxSizePost;
                ViewBag.CustomerName = ((Customers)Session["customer"]).Customer_name;
                ViewBag.CustomerPrefix = ((Customers)Session["customer"]).Prefix;
                return View();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public ActionResult ViewLoadedOrder()
        {
            var customer = ((Customers)Session["customer"]);
            ViewBag.Title = "Visualizar pedido";
            ViewBag.jsRoles = new string[] { "jq-datatable" };
            ViewBag.CustomerName = customer.Customer_name;
            return View();
        }


        public ActionResult FileContent(int id)
        {
            using (var Context = new Master_Context(GlobalConfiguration.ConnectionString))
            {
                var customer = ((Customers)Session["customer"]);
                var document = Context.HistoryUploadsFiles.SingleOrDefault(item => item.Id == id && item.CustomerId == customer.Id);
                if (document == null)
                {
                    TempData["messager"] = JsonConvert.SerializeObject(new MensagerModel(Mensager.Warning)
                    {
                        Title = "<strong>Documento desconocido</strong>",
                        Content = string.Format("No se localizo el documento deseado")
                    }, Formatting.Indented);
                    return RedirectToAction("ViewLoadedOrder", "Customers");
                }


                ViewBag.Title = string.Format("Documento : {0}", document.FileName);
                ViewBag.FileId = document.Id;
                ViewBag.Document = document.FileName;
                ViewBag.jsRoles = new string[] { "jq-datatable" };

            }

            return View();
        }


        [Authorize]
        public ActionResult ViewOrders()
        {
            // Visualizar pedidos

            var customer = ((Customers)Session["customer"]);
            var process = ProcessFactory.Factory.Create(customer.Prefix);
            process.UserId = User.Identity.GetUserId<string>();

            // Se genera el DropDownList con los documentos cargados
            IEnumerable<SelectListItem> root = new List<SelectListItem>() { new SelectListItem() { Text = "-- Seleccione --", Value = "-1", Disabled = true, Selected = true } };
            IEnumerable<SelectListItem> list = (from xelem in process.GetFiles()
                                                select new SelectListItem
                                                {
                                                    Value = Convert.ToString(xelem.Id),
                                                    Text = xelem.FileName,
                                                    Disabled = false,
                                                }).ToList();

            ViewBag.Title = "Artículos";
            ViewBag.jsRoles = new string[] { "jq-datatable" };
            ViewBag.ListFiles = root.Union(list);
            ViewBag.CustomerPrefix = customer.Prefix;
            ViewBag.ListCategories = null;
            ViewBag.ListClasifications = null;

            return View();
        }

        #region json

        [Authorize]
        [HttpPost]
        public JsonResult jsLoadedOrders(jQueryDataTableParamModel param)
        {
            try
            {
                // Regresa los pedidos cargados por cliente
                var customer = ((Customers)Session["customer"]);
                var _json = new jQueryDataTableResponseModel();
                using (var Context = new Master_Context(GlobalConfiguration.ConnectionString))
                {
                    param.search = Request.Params["search[value]"];

                    var TotalRecords = Context.HistoryUploadsFiles.Where(item => item.CustomerId == customer.Id).Count();
                    var account_total = TotalRecords;
                    int length = (param.length != -1) ? param.length : TotalRecords;
                    var pedidos = (from item in Context.HistoryUploadsFiles
                                   where item.CustomerId == customer.Id
                                   orderby item.Id descending
                                   select new
                                   {
                                       item.Id,
                                       item.FileName,
                                       item.LoadDate,
                                       item.Status,
                                       WorkStation = item.WorkStation.ToUpper()
                                   }).Skip(param.start).Take(length).ToList();

                    _json = new jQueryDataTableResponseModel()
                    {
                        sEcho = param.draw,
                        recordsTotal = TotalRecords,
                        recordsFiltered = account_total,
                        iTotalRecords = TotalRecords,
                        iTotalDisplayRecords = account_total,
                        aaData = pedidos
                    };

                    return Json(_json, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Authorize]
        [HttpPost]
        public JsonResult jsFileContent(jQueryDataTableParamModel param)
        {
            try
            {
                // Regresa los pedidos cargados por cliente
                var customer = ((Customers)Session["customer"]);
                var _json = new jQueryDataTableResponseModel();
                using (var Context = new Master_Context(GlobalConfiguration.ConnectionString))
                {
                    param.search = Request.Params["search[value]"];
                    int FileId = Convert.ToInt32(Request.Params["FileId"]);
                    var TotalRecords = Context.PedidosSap.Where(item => item.Customer_Id == customer.Id && item.File_Id == FileId).Count();
                    var account_total = TotalRecords;
                    int length = (param.length != -1) ? param.length : TotalRecords;

                    var pedidos = (from item in Context.PedidosSap
                                   where item.Customer_Id == customer.Id && item.File_Id == FileId
                                   orderby item.Id descending
                                   select new
                                   {
                                       item.Id,
                                       item.Article_No,
                                       item.Article_Name,
                                       item.Sales_Organization,
                                       item.Release_Strategy,
                                       item.Customer_No,
                                       item.Sold_To_Name,
                                       item.Ship_To,
                                       item.Ship_To_Name,
                                       item.Sales_Type,
                                       item.Customer_Purchase_No,
                                       item.RDD,
                                       item.Format
                                   }).Skip(param.start).Take(length).ToList();

                    _json = new jQueryDataTableResponseModel()
                    {
                        sEcho = param.draw,
                        recordsTotal = TotalRecords,
                        recordsFiltered = account_total,
                        iTotalRecords = TotalRecords,
                        iTotalDisplayRecords = account_total,
                        aaData = pedidos
                    };

                    return Json(_json, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Authorize]
        [HttpPost]
        public JsonResult jsUpload(string CustomerPrefix, HttpPostedFileBase FileAttach)
        {
            string json_result = "{}";
            try
            {
                if (FileAttach != null && FileAttach.ContentLength > 0)
                {
                    /* Se leen los datos del archivo y se importan a la base de datos */
                    var customer = ((Customers)Session["customer"]);
                    ExcelReader.Create(FileAttach.InputStream, FileAttach.FileName);
                    DataTable datas = ExcelReader.AsDataSet("Sheet1");
                    datas.Columns.Add(new DataColumn() { ColumnName = "customer_id", DataType = typeof(int), DefaultValue = customer.Id, AllowDBNull = false });

                    var process = ProcessFactory.Factory.Create(CustomerPrefix);
                    process.UserId = User.Identity.GetUserId<string>();
                    process.UploadDatas(datas, FileAttach.FileName);

                    json_result = JsonConvert.SerializeObject(new MensagerModel(Mensager.Success)
                    {
                        Title = "<strong>Importacion correcta</strong>",
                        Content = string.Format("Se importo el archivo <string>{0}</strong> correctamente, {1} filas al sistema", FileAttach.FileName, datas.Rows.Count)
                    }, Formatting.Indented);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(string.Concat("Upload File: ", ex.ToString()));
                json_result = JsonConvert.SerializeObject(new MensagerModel(Mensager.Danger)
                {
                    Title = "<strong>Exepción</strong>",
                    Content = string.Format("{0}", Helper.GetInnerException(ex))
                }, Formatting.Indented);
            }

            return Json(json_result, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpPost]
        public JsonResult jsGetCustumer()
        {
            try
            {
                // Genera una lista de los clientes registrados en el sistema
                string js_result = "";
                using (var Context = new Master_Context(GlobalConfiguration.ConnectionString))
                {
                    var custumers = Context.Customers
                        .Where(o => o.Prefix != "SYS")
                        .Select(o => new
                        {
                            o.Id,
                            o.Customer_name,
                            o.Prefix
                        });

                    js_result = JsonConvert.SerializeObject(custumers, Formatting.None);
                }

                return Json(js_result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Authorize]
        [HttpPost]
        public JsonResult jsonArticles(jQueryDataTableParamModel param)
        {
            try
            {
                int FileId = Convert.ToInt32(Request.Params["FileId"]);
                var customer = ((Customers)Session["customer"]);
                var _json = new jQueryDataTableResponseModel();
                using (var Context = new Master_Context(GlobalConfiguration.ConnectionString))
                {

                    param.search = Request.Params["search[value]"];
                    var TotalRecords = Context.PedidosSap.Where(item => item.File_Id == FileId && item.Customer_Id == customer.Id).Count();
                    var account_total = TotalRecords; //Context.PedidosSap.Where(item => item.File_Id == FileId && item.Customer_Id == customer.Id).Count();

                    int length = (param.length != -1) ? param.length : TotalRecords;
                    var pedidos = (from item in Context.Vw_articles_sap
                                   where item.File_id == FileId && item.Customer_id == customer.Id
                                   orderby item.RowNumber descending
                                   select new
                                   {
                                       item.Article_no,
                                       item.Article_description,
                                       item.Color,
                                       item.Category,
                                       item.Marca,
                                       item.Type,
                                       item.Tecnology,
                                       item.Size,
                                       item.Equivalent_size
                                   }).Skip(param.start).Take(length).ToList();

                    _json = new jQueryDataTableResponseModel()
                    {
                        sEcho = param.draw,
                        recordsTotal = TotalRecords,
                        recordsFiltered = account_total,
                        iTotalRecords = TotalRecords,
                        iTotalDisplayRecords = account_total,
                        aaData = pedidos
                    };

                }

                return Json(_json, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

    }
}