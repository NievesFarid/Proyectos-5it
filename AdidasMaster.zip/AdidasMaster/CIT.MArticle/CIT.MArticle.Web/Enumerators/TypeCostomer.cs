﻿namespace CIT.MArticle.Web.Enumerators
{
    public enum TypeCostomer
    {
        Liverpool = 1,
        Marti = 2
    }
}