﻿using CIT.MArticle.Infrastructure;
using System.Configuration;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace CIT.MArticle.Web
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            // configuraciones

            Global.ConnectionString = ConfigurationManager.ConnectionStrings["CIT.MArticle.Web.Properties.Settings.ADMaster_Conenction"].ConnectionString;
            
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
    }
}
