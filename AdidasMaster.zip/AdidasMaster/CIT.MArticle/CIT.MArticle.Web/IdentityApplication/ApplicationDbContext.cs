﻿using CIT.MArticle.Web;
using IdentityApplication.Model;
using Microsoft.AspNet.Identity.EntityFramework;

namespace IdentityApplication
{
    public class ApplicationDbContext : IdentityDbContext<IdentityUserModel>
    {

        public ApplicationDbContext(string connection) : base(connection, throwIfV1Schema: false)
        {
            Configuration.ProxyCreationEnabled = false;
        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext(GlobalConfiguration.ConnectionString);
        }

    }
}