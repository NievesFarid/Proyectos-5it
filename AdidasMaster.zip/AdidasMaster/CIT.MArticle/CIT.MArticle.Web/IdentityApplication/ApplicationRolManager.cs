﻿using IdentityApplication.Model;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;

namespace IdentityApplication
{
    public class ApplicationRolManager : RoleManager<IdentityRoleModel>
    {
        //private static readonly RoleStore<IdentityRoleModel> Store = new RoleStore<IdentityRoleModel>(ApplicationDbContext.Create());
        //private static readonly RoleManager<IdentityRoleModel> Manager = new RoleManager<IdentityRoleModel>(Store);

        public ApplicationRolManager(IRoleStore<IdentityRoleModel, string> store) : base(store)
        {

        }

        public static ApplicationRolManager Create(IdentityFactoryOptions<ApplicationRolManager> options, IOwinContext context)
        {
            var manager = new ApplicationRolManager(new RoleStore<IdentityRoleModel>(context.Get<ApplicationDbContext>()));
            return manager;
            //var roleStore = new RoleStore<IdentityRoleModel>(context.Get<ApplicationDbContext>());
            //return new ApplicationRolManager(roleStore);
        }

    }
}