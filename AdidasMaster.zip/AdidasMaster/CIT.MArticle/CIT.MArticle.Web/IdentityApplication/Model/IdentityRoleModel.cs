﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace IdentityApplication.Model
{
    public class IdentityRoleModel : IdentityRole
    {
       
    }
}