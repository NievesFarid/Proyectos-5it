﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIT.MArticle.Web.Enumerators;

namespace CIT.MArticle.Web.Interfaces
{
    public interface IProcess
    {
        /// <summary>
        /// Tipo de cliente
        /// </summary>
        TypeCostomer ProccessType { get; }

        /// <summary>
        /// Numero de cliente
        /// </summary>
        int NumberClient { get; set; }


        void Create();

        /// <summary>
        /// Sube los datos al servidor SQL Server
        /// </summary>
        /// <param name="tDatas"></param>
        void UploadDatas(DataTable tDatas);
    }
}

