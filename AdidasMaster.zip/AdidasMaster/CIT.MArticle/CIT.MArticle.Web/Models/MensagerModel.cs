﻿using System.Text;

namespace CIT.MArticle.Web.Models
{
    public class MensagerModel
    {
        private Mensager mensager;

        /// <summary>
        /// Titulo de la notificación
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Contenido de la notificación
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// Tiempo de espera para ocultar la notificación
        /// </summary>
        public int Timeout { get { return GlobalConfiguration.BoxNotificationTimeout; } }

        /// <summary>
        /// Color de la notificación
        /// </summary>
        public string Color
        {
            get
            {
                switch (mensager)
                {
                    case Mensager.Info:
                        return "#ff6849";
                    case Mensager.Success:
                        return "#739E73";
                    case Mensager.Warning:
                        return "#C79121";
                    case Mensager.Danger:
                        return "#C46A69";
                    default:
                        return "#ff6849"; // => Success
                }
            }

        }

        /// <summary>
        /// Icono de la notificación
        /// </summary>
        public string Icon
        {
            get
            {
                switch (mensager)
                {
                    case Mensager.Info:
                        return "info";
                    case Mensager.Success:
                        return "success";
                    case Mensager.Warning:
                        return "warning";
                    case Mensager.Danger:
                        return "error";
                    default:
                        return "info"; // => Success
                }
            }
        }

        public MensagerModel(Mensager mensager)
        {
            this.mensager = mensager;
        }

        /// <summary>
        /// Escribe la notifación
        /// </summary>
        /// <returns></returns>
        public string WriteNotification()
        {
            /*Ref: https://kamranahmed.info/toast */

            StringBuilder Notification = new StringBuilder();
            Notification.Append("$.toast({ ");
            Notification.Append(string.Format("heading : '{0}', ", Title));
            Notification.Append(string.Format("text : '{0}', ", Content));
            Notification.Append(string.Format("position : 'top-right', "));
            Notification.Append(string.Format("loaderBg : '{0}', ", Color));
            Notification.Append(string.Format("icon : '{0}', ", Icon));
            Notification.Append(string.Format("hideAfter : {0}, ", Timeout));
            Notification.Append("stack: 3");
            Notification.Append(" });");
            return Notification.ToString();
        }
    }
}