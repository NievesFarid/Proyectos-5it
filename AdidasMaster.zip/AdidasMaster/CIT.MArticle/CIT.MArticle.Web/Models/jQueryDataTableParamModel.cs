﻿namespace CIT.MArticle.Web.Models
{
    public class jQueryDataTableParamModel
    {
        /// <summary>
        /// Request sequence number sent by DataTable,
        /// same value must be returned in response
        /// </summary>       
        public string sEcho { get; set; }

        /// <summary>
        /// Dibujar contador. DataTables utiliza esto para garantizar que los retornos Ajax de las solicitudes 
        /// de procesamiento del lado del servidor se dibujan en secuencia mediante
        /// DataTables (las solicitudes Ajax son asíncronas y, por lo tanto, 
        /// pueden devolverse fuera de secuencia). Esto se utiliza como parte del parámetro de retorno 
        /// de extracción
        /// </summary>
        public int draw { get; set; }


        /// <summary>
        /// Text used for filtering
        /// </summary>
        public string sSearch { get; set; }

        /// <summary>
        /// Valor de búsqueda global. Para ser aplicado a todas las columnas que se pueden buscar como verdaderas.
        /// </summary>
        public string search { get; set; }

        /// <summary>
        /// Number of records that should be shown in table
        ///  <para>Número de registros que la tabla puede mostrar en el sorteo actual.
        ///  Se espera que la cantidad de registros devueltos sea igual a este número, 
        ///  a menos que el servidor tenga menos registros para devolver.
        ///  </para>
        /// </summary>
        public int iDisplayLength { get; set; }

        /// <summary>
        /// Número de registros que la tabla puede mostrar en el sorteo actual. 
        /// Se espera que la cantidad de registros devueltos sea igual a este número, 
        /// a menos que el servidor tenga menos registros para devolver. 
        /// Tenga en cuenta que esto puede ser -1 para indicar que todos los registros
        /// deben devolverse (¡aunque eso anula cualquier beneficio del procesamiento del lado del servidor!)
        /// </summary>
        public int length { get; set; }

        /// <summary>
        /// First record that should be shown(used for paging)
        /// <para> Mostrar el punto de inicio en el conjunto de datos actual.</para>
        /// </summary>
        public int iDisplayStart { get; set; }

        /// <summary>
        /// Indicador de primer registro de paginación. 
        /// Este es el punto de inicio en el conjunto de datos actual (0 basado en el índice, es decir, 
        /// 0 es el primer registro).
        /// </summary>
        public int start { get; set; }

        /// <summary>
        /// Número de columnas que se muestran (útil para obtener información de búsqueda de columnas individuales)
        /// </summary>
        public int iColumns { get; set; }

        /// <summary>
        /// Number of columns that are used in sorting
        /// </summary>
        public int iSortingCols { get; set; }

        /// <summary>
        /// Comma separated list of column names
        /// </summary>
        public string sColumns { get; set; }

        /// <summary>
        /// Verdadero si el filtro global se debe tratar como una expresión regular para el filtrado avanzado, falso si no.
        /// </summary>
        public bool bRegex { get; set; }
    }
}