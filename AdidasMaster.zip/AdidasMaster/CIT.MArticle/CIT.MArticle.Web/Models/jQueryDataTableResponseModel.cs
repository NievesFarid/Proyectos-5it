﻿namespace CIT.MArticle.Web.Models
{
    public class jQueryDataTableResponseModel
    {

        /// <summary>
        /// Una copia inalterada de sEcho enviada desde el lado del cliente.
        /// Este parámetro cambiará con cada sorteo (es básicamente un recuento de sorteos),
        /// por lo que es importante que esto se implemente. 
        /// Tenga en cuenta que, por razones de seguridad, se recomienda encarecidamente que 'convierta'
        /// este parámetro a un entero para evitar ataques de secuencias de comandos entre sitios (XSS).
        /// </summary>
        //public int draw { get; set; }
        public int sEcho { get; set; }

        /// <summary>
        /// Total de registros, antes del filtrado (es decir, el número total de registros en la base de datos)
        /// </summary>
        public int recordsTotal { get; set; }

        /// <summary>
        /// Registros totales, después del filtrado (es decir, el número total de registros después de que se haya aplicado el filtrado, 
        /// no solo el número de registros que se devuelven en este conjunto de resultados)
        /// </summary>
        public int recordsFiltered { get; set; }

        public int iTotalRecords { get; set; }
        public int iTotalDisplayRecords { get; set; }

        /// <summary>
        /// Los datos en una matriz 2D. Tenga en cuenta que puede cambiar el nombre de este parámetro con sAjaxDataProp.
        /// http://legacy.datatables.net/usage/options#sAjaxDataProp
        /// </summary>
        //public object data { get; set; }
        public object aaData { get; set; }

        /// <summary>
        /// Opcional: si se produce un error durante la ejecución del script de procesamiento del lado del servidor, 
        /// puede informar al usuario de este error devolviendo el mensaje de error que se muestra con este parámetro. 
        /// No incluir si no hay error.
        /// </summary>
        //public string error { get; set; }

    }
}