﻿using CIT.MArticle.Web.Enumerators;
using CIT.MArticle.Web.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace CIT.MArticle.Web
{
    public class ProcessFactory
    {
        private List<IProcess> _processes;
        private static ProcessFactory instance;

        private ProcessFactory()
        {
            _processes = new List<IProcess>();
            var assm = GetType().AssemblyQualifiedName.Split(',');
            _processes = Assembly.Load(assm[1]).GetTypes()
               .Where(itm => itm != null && itm.IsClass && itm.GetInterfaces().Any(ti => ti == typeof(IProcess)))
               .Select(type => (IProcess)Activator.CreateInstance(type)).ToList();
        }

        public static ProcessFactory Factory
        {
            get
            {
                if (instance == null)
                    instance = new ProcessFactory();
                return instance;
            }
        }

        public IProcess Create(TypeCostomer _type)
        {
            return _processes.FirstOrDefault(cmd => cmd.ProccessType == _type);
        }

    }
}