﻿using CIT.MArticle.Web.Enumerators;
using CIT.MArticle.Web.Interfaces;
using System;
using System.Data;

namespace CIT.MArticle.Web.Processes
{
    public class MartiProcess : IProcess
    {

        public int NumberClient { get; set; }

        /// <summary>
        /// Tipo de proceso
        /// </summary>
        public TypeCostomer ProccessType => TypeCostomer.Marti;


        public void Create()
        {

        }

        /// <summary>
        /// Sube los datos al servidor SQL Server
        /// </summary>
        /// <param name="tDatas"></param>
        public void UploadDatas(DataTable tDatas)
        {
            try
            {

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}