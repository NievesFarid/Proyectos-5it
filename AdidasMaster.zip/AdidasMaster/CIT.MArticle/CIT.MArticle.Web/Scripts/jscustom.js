﻿
/**
 * Realiza una llamada de tipo async y devuelve un json como resultado
 * @param {any} url
 * @param {any} params
 * @param {any} handleData
 */
function jsonCallback(url, params, handleData) {
    $.ajax({
        type: "POST", url: url, dataType: "json", data: params,
        success: function (data) { handleData(data); },
        error: function (jqXHR, textStatus, errorThrown) { console.log(jqXHR.status); console.log(textStatus); console.log(errorThrown); }
    });
}

/**
 * Pobla de datos a una lista en pantalla
 * @param {any} html_object
 * @param {any} data_array
 */
function Set_dataList(html_object, dataJson) {
    var select_elem = $("#" + html_object);
    select_elem.empty();
    $.each(dataJson, function (idx, obj) {
        select_elem.append('<option value="' + obj.value + '">' + obj.display + '</option>');
    });
}

/**
 * Abre una pagina nueva con la ruta especificada
 * @param {any} url
 * @param {any} title
 */
function openWindow(url, title) {
    width = ($(window).width() * .60);
    var configuracion = "menubar=yes,location=yes,resizable=yes,scrollbars=yes,status=yes,titlebar=yes,width=" + width;
    windowObjectReference = window.open(url, title, configuracion);
}